# PROC38-1_4-actividad-alumno1
## Plantilla de la actividad del alumno 1 para la clase 38 nivel PRO 1:4.
### Nombre en ingles: C37-SpeedRacer_ReferenceCode

Etapa 2
